using System;
using Server.Mobiles;
namespace Server.Items
{
    public class PackAnimalContract : Item
    {
        [Constructable]
        public PackAnimalContract() : base(0x14F0)
        {
            Name = "����/���� �絵 ��༭";
            Hue = 0x288;
            Weight = 1.0;
        }
        public override void OnDoubleClick(Mobile from)
        {
            if (!IsChildOf(from.Backpack)) { from.SendLocalizedMessage(1042001); return; }
            BaseCreature pet = Utility.RandomBool() ? (BaseCreature)new PackHorse() : new PackLlama();
            pet.Controlled = true;
            pet.ControlMaster = from;
            pet.ControlOrder = OrderType.Follow;
            pet.MoveToWorld(from.Location, from.Map);
            from.SendMessage(68, "��༭�� ����Ͽ� ���� ������ ��ȯ�߽��ϴ�.");
            this.Delete();
        }
        public PackAnimalContract(Serial serial) : base(serial) { }
        public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int)0); }
        public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
    }
}
