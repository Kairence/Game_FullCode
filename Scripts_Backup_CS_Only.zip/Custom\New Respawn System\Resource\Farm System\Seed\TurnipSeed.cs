using System;

namespace Server.Items
{
    public class TurnipSeed : BaseSeed
    {
        // Turnip Ŭ������ �����Ѵٰ� �����մϴ�.
        public override Type CropType => typeof(Turnip);
        public override double MinSkill => 15.0;
        public override double MaxSkill => 65.0;

        [Constructable]
        public TurnipSeed() : base(0xDCF)
        {
            Hue = 0x1F6;
            Name = "���� ����";
        }

        public TurnipSeed(Serial serial) : base(serial) { }
        public override void Serialize(GenericWriter writer) { base.Serialize(writer); writer.Write((int)0); }
        public override void Deserialize(GenericReader reader) { base.Deserialize(reader); int version = reader.ReadInt(); }
    }
}

