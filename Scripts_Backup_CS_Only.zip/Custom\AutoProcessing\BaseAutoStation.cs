using System;
using Server;
using Server.Items;
using Server.Targeting;
using Server.Network;

namespace Server.Custom.AutoProcessing
{
    public abstract class BaseAutoStation : Item
    {
        private int m_InputCount;
        private int m_OutputCount;
        private DateTime m_NextProcessTime;
        public static System.Collections.Generic.HashSet<BaseAutoStation> ActiveStations = new System.Collections.Generic.HashSet<BaseAutoStation>();

        [CommandProperty(AccessLevel.GameMaster)]
        public int InputCount { get { return m_InputCount; } set { m_InputCount = value; InvalidateProperties(); } }

        [CommandProperty(AccessLevel.GameMaster)]
        public int OutputCount { get { return m_OutputCount; } set { m_OutputCount = value; InvalidateProperties(); } }

        public abstract Type InputType { get; }
        public abstract Type OutputType { get; }
        public abstract int MaxCapacity { get; }
        public abstract TimeSpan ProcessingInterval { get; }
        public abstract int ProcessAmountPerTick { get; }
        
        public abstract int InputPerOutput { get; }

        public abstract int WorkingItemID { get; }
        public abstract int IdleItemID { get; }
        public abstract int WorkingSound { get; }

        public BaseAutoStation(int itemID) : base(itemID)
        {
            Movable = false;
        }

        public BaseAutoStation(Serial serial) : base(serial)
        {
        }

        public override void GetProperties(ObjectPropertyList list)
        {
            base.GetProperties(list);
            list.Add(1060658, "�����\t{0} / {1}", m_InputCount, MaxCapacity); 
            list.Add(1060659, "�ϼ�ǰ\t{0}", m_OutputCount);
            
            if (ActiveStations.Contains(this))
                list.Add(1060660, "����\t���� ��...");
            else
                list.Add(1060661, "����\t��� ��");
        }

        public override bool OnDragDrop(Mobile from, Item dropped)
        {
            if (dropped.GetType() == InputType)
            {
                if (m_InputCount >= MaxCapacity)
                {
                    from.SendMessage("�� �̻� ����Ḧ ���� �� �����ϴ�.");
                    return false;
                }

                int canAdd = MaxCapacity - m_InputCount;
                int toAdd = Math.Min(dropped.Amount, canAdd);

                m_InputCount += toAdd;
                dropped.Consume(toAdd);

                from.SendMessage("{0}���� ����Ḧ �־����ϴ�.", toAdd);
                
                CheckStartTimer();
                InvalidateProperties();
                return true;
            }
            
            from.SendMessage("�� ��迡�� ���� �� ���� �����Դϴ�.");
            return false;
        }

        public override void OnDoubleClick(Mobile from)
        {
            if (!from.InRange(GetWorldLocation(), 2))
            {
                from.LocalOverheadMessage(MessageType.Regular, 0x3B2, 1019045); // I can't reach that.
                return;
            }

            if (m_OutputCount > 0)
            {
                Item output = (Item)Activator.CreateInstance(OutputType);
                output.Amount = m_OutputCount;
                
                if (from.AddToBackpack(output))
                {
                    from.SendMessage("{0}���� �ϼ�ǰ�� ȸ���߽��ϴ�.", m_OutputCount);
                    m_OutputCount = 0;
                    InvalidateProperties();
                }
                else
                {
                    output.Delete();
                    from.SendMessage("������ ���� �� �ϼ�ǰ�� ȸ���� �� �����ϴ�.");
                }
            }
            else if (m_InputCount == 0)
            {
                from.SendMessage("������ ����Ḧ �����ϼ���.");
                from.Target = new StationTarget(this);
            }
            else
            {
                from.SendMessage("��谡 ���� ���Դϴ�. ��ø� ��ٷ��ּ���.");
            }
        }

        private class StationTarget : Target
        {
            private BaseAutoStation m_Station;
            public StationTarget(BaseAutoStation station) : base(2, false, TargetFlags.None)
            {
                m_Station = station;
            }
            protected override void OnTarget(Mobile from, object targeted)
            {
                if (targeted is Item item && item.IsChildOf(from.Backpack))
                {
                    m_Station.OnDragDrop(from, item);
                }
                else
                {
                    from.SendMessage("���� ���� ����Ḹ ���� �� �ֽ��ϴ�.");
                }
            }
        }

                public void CheckStartTimer()
        {
            if (m_InputCount >= InputPerOutput)
            {
                if (!ActiveStations.Contains(this))
                {
                    ActiveStations.Add(this);
                    m_NextProcessTime = DateTime.Now + ProcessingInterval;
                    ItemID = WorkingItemID;
                    InvalidateProperties();
                }
            }
        }


                public void ProcessTick()
        {
            if (Deleted) return;
            
            if (m_InputCount >= InputPerOutput)
            {
                if (DateTime.Now >= m_NextProcessTime)
                {
                    int processCount = Math.Min(m_InputCount / InputPerOutput, ProcessAmountPerTick);
                    
                    m_InputCount -= (processCount * InputPerOutput);
                    m_OutputCount += processCount;

                    if (WorkingSound > 0)
                        Effects.PlaySound(Location, Map, WorkingSound);
                        
                    m_NextProcessTime = DateTime.Now + ProcessingInterval;
                    InvalidateProperties();
                }
            }

            if (m_InputCount < InputPerOutput)
            {
                StopWorking();
            }
        }

        public void StopWorking()
        {
            ActiveStations.Remove(this);
            ItemID = IdleItemID;
            InvalidateProperties();
        }
                public static void GlobalTick()
        {
            if (ActiveStations.Count == 0) return;
            
            var list = new System.Collections.Generic.List<BaseAutoStation>(ActiveStations);
            foreach (var station in list)
            {
                if (station != null && !station.Deleted)
                {
                    station.ProcessTick();
                }
                else
                {
                    ActiveStations.Remove(station);
                }
            }
        }

        public override void OnDelete()
        {
            StopWorking();
            base.OnDelete();
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);
            writer.Write((int)0);
            writer.Write(m_InputCount);
            writer.Write(m_OutputCount);
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);
            int version = reader.ReadInt();
            m_InputCount = reader.ReadInt();
            m_OutputCount = reader.ReadInt();

            CheckStartTimer();
        }
    }
}

